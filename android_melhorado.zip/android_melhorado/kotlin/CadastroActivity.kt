package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class CadastroActivity : AppCompatActivity() {

    private var categoriaId: Int? = null
    private var modoEdicao = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        val editNome   = findViewById<TextInputEditText>(R.id.editNome)
        val btnSalvar  = findViewById<MaterialButton>(R.id.btnSalvar)
        val btnExcluir = findViewById<MaterialButton>(R.id.btnExcluir)
        val txtTitulo  = findViewById<TextView>(R.id.txtTitulo)
        val btnVoltar  = findViewById<View>(R.id.btnVoltar)

        // Verifica se veio com dados (modo edição)
        categoriaId = intent.getIntExtra("ID_CATEGORIA", -1).takeIf { it != -1 }
        val nomeExistente = intent.getStringExtra("NOME_CATEGORIA")

        if (categoriaId != null && nomeExistente != null) {
            modoEdicao = true
            txtTitulo.text = "Editar Categoria"
            editNome.setText(nomeExistente)
            btnSalvar.text = "Salvar Alterações"
            btnExcluir.visibility = View.VISIBLE
        }

        btnVoltar.setOnClickListener { finish() }

        btnSalvar.setOnClickListener {
            val nome = editNome.text.toString().trim()
            if (nome.isEmpty()) {
                editNome.error = "Digite um nome para a categoria"
                return@setOnClickListener
            }
            if (modoEdicao) atualizarCategoria(nome) else criarCategoria(nome)
        }

        btnExcluir.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Excluir categoria")
                .setMessage("Tem certeza? Esta ação não pode ser desfeita.")
                .setPositiveButton("Excluir") { _, _ -> excluirCategoria() }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun criarCategoria(nome: String) {
        lifecycleScope.launch {
            try {
                RetrofitClient.instancia.criarCategoria(Categoria(nome = nome))
                Toast.makeText(this@CadastroActivity, "Categoria criada! ✅", Toast.LENGTH_SHORT).show()
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@CadastroActivity, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun atualizarCategoria(nome: String) {
        val id = categoriaId ?: return
        lifecycleScope.launch {
            try {
                RetrofitClient.instancia.atualizarCategoria(id, Categoria(nome = nome))
                Toast.makeText(this@CadastroActivity, "Categoria atualizada! ✅", Toast.LENGTH_SHORT).show()
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@CadastroActivity, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun excluirCategoria() {
        val id = categoriaId ?: return
        lifecycleScope.launch {
            try {
                RetrofitClient.instancia.deletarCategoria(id)
                Toast.makeText(this@CadastroActivity, "Categoria excluída!", Toast.LENGTH_SHORT).show()
                finish()
            } catch (e: Exception) {
                Toast.makeText(this@CadastroActivity, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
