package com.example.myapplication

// ── Data Classes ─────────────────────────────────────────────────────────────

data class Categoria(
    val id: Int? = null,
    val nome: String
)

data class Produto(
    val id: Int? = null,
    val nome: String,
    val preco: Double? = null,
    val categoria_id: Int? = null
)

// ── ProdutoAdapter ────────────────────────────────────────────────────────────

package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProdutoAdapter(private val lista: List<Produto>) :
    RecyclerView.Adapter<ProdutoAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nome: TextView  = view.findViewById(R.id.nomeProduto)
        val preco: TextView = view.findViewById(R.id.precoProduto)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_produto, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val produto = lista[position]
        holder.nome.text  = produto.nome
        holder.preco.text = produto.preco?.let { "R$ %.2f".format(it) } ?: ""
    }

    override fun getItemCount() = lista.size
}
