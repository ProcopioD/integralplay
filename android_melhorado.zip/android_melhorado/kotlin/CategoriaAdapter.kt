package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CategoriaAdapter(
    private val lista: List<Categoria>,
    private val onClickItem: (Categoria) -> Unit,
    private val onClickEditar: (Categoria) -> Unit
) : RecyclerView.Adapter<CategoriaAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nome: TextView      = view.findViewById(R.id.nomeCategoria)
        val btnEditar: ImageView = view.findViewById(R.id.btnEditar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_categoria, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val categoria = lista[position]
        holder.nome.text = categoria.nome

        // Clique no card inteiro → abre produtos
        holder.itemView.setOnClickListener { onClickItem(categoria) }

        // Clique no lápis → abre edição (sem propagar para o card)
        holder.btnEditar.setOnClickListener { v ->
            v.parent.requestDisallowInterceptTouchEvent(true)
            onClickEditar(categoria)
        }
    }

    override fun getItemCount() = lista.size
}
