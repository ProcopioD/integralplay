package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var cardLoading: View
    private lateinit var cardVazio: View
    private lateinit var txtContagem: TextView
    private lateinit var fabAdicionar: ExtendedFloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView   = findViewById(R.id.meuRecyclerView)
        cardLoading    = findViewById(R.id.cardLoading)
        cardVazio      = findViewById(R.id.cardVazio)
        txtContagem    = findViewById(R.id.txtContagem)
        fabAdicionar   = findViewById(R.id.fabAdicionar)

        recyclerView.layoutManager = LinearLayoutManager(this)

        fabAdicionar.setOnClickListener {
            startActivity(Intent(this, CadastroActivity::class.java))
        }

        carregarCategorias()
    }

    override fun onResume() {
        super.onResume()
        // Recarrega ao voltar de Cadastro ou Edição
        carregarCategorias()
    }

    private fun carregarCategorias() {
        mostrarEstado("carregando")

        lifecycleScope.launch {
            try {
                val lista = RetrofitClient.instancia.listarCategorias()

                txtContagem.text = lista.size.toString()

                if (lista.isEmpty()) {
                    mostrarEstado("vazio")
                } else {
                    mostrarEstado("lista")
                    recyclerView.adapter = CategoriaAdapter(
                        lista = lista,
                        onClickItem = { categoria ->
                            // Abre produtos da categoria
                            val intent = Intent(this@MainActivity, ProdutosActivity::class.java)
                            intent.putExtra("ID_CATEGORIA", categoria.id)
                            intent.putExtra("NOME_CATEGORIA", categoria.nome)
                            startActivity(intent)
                        },
                        onClickEditar = { categoria ->
                            // Abre tela de edição
                            val intent = Intent(this@MainActivity, CadastroActivity::class.java)
                            intent.putExtra("ID_CATEGORIA", categoria.id)
                            intent.putExtra("NOME_CATEGORIA", categoria.nome)
                            startActivity(intent)
                        }
                    )
                }
            } catch (e: Exception) {
                mostrarEstado("vazio")
                Toast.makeText(
                    this@MainActivity,
                    "Erro ao carregar: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun mostrarEstado(estado: String) {
        cardLoading.visibility  = if (estado == "carregando") View.VISIBLE else View.GONE
        cardVazio.visibility    = if (estado == "vazio")      View.VISIBLE else View.GONE
        recyclerView.visibility = if (estado == "lista")      View.VISIBLE else View.GONE
    }
}
