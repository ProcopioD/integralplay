package com.example.myapplication

import retrofit2.http.*

interface ApiService {

    // ── CATEGORIAS ──────────────────────────────────────────
    @GET("categorias")
    suspend fun listarCategorias(): List<Categoria>

    @POST("categorias")
    suspend fun criarCategoria(@Body categoria: Categoria): Categoria

    @PUT("categorias/{id}")
    suspend fun atualizarCategoria(
        @Path("id") id: Int,
        @Body categoria: Categoria
    ): Any

    @DELETE("categorias/{id}")
    suspend fun deletarCategoria(@Path("id") id: Int): Any

    // ── PRODUTOS ─────────────────────────────────────────────
    // Ajuste a rota conforme sua API — exemplos comuns:
    // "produtos?categoria_id={id}" ou "categorias/{id}/produtos"
    @GET("produtos")
    suspend fun listarProdutos(@Query("categoria_id") categoriaId: Int): List<Produto>
}
