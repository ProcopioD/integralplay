package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class ProdutosActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_produtos)

        val txtNomeCategoria = findViewById<TextView>(R.id.txtNomeCategoria)
        val recycler         = findViewById<RecyclerView>(R.id.recyclerProdutos)
        val progressBar      = findViewById<ProgressBar>(R.id.progressBar)
        val cardVazio        = findViewById<View>(R.id.cardVazio)
        val btnVoltar        = findViewById<View>(R.id.btnVoltar)

        val idCategoria   = intent.getIntExtra("ID_CATEGORIA", 0)
        val nomeCategoria = intent.getStringExtra("NOME_CATEGORIA") ?: "Produtos"

        txtNomeCategoria.text = nomeCategoria
        recycler.layoutManager = LinearLayoutManager(this)

        btnVoltar.setOnClickListener { finish() }

        lifecycleScope.launch {
            try {
                val produtos = RetrofitClient.instancia.listarProdutos(idCategoria)

                progressBar.visibility = View.GONE

                if (produtos.isEmpty()) {
                    cardVazio.visibility = View.VISIBLE
                } else {
                    recycler.visibility = View.VISIBLE
                    recycler.adapter = ProdutoAdapter(produtos)
                }
            } catch (e: Exception) {
                progressBar.visibility = View.GONE
                cardVazio.visibility = View.VISIBLE
                Toast.makeText(
                    this@ProdutosActivity,
                    "Erro ao carregar produtos: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
